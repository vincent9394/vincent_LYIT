# Tik-Tak-Toe-AI
A Game Created with the minimax algorithm and the game engine pygame

![alt text](https://github.com/Mice0x/Tik-Tak-Toe-AI/blob/master/Screenshot.png)
